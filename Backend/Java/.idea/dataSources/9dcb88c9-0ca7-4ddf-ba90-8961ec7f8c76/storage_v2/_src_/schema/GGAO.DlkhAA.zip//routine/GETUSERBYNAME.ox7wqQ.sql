create procedure getuserbyname(
	nm in SAMPLE.NAME%TYPE,
	ag out SAMPLE.AGE%TYPE
    )
   is
   begin
	select s.age into ag
    from sample s
    where s.name = nm;
   end;
/

