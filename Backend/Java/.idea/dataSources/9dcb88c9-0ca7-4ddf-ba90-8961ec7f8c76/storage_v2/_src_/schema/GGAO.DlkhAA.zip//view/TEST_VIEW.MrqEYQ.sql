create view TEST_VIEW as
select AGE, TN from test3
/

