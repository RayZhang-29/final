create view SV as
select age from sample
/

