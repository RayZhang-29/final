create function QUERYUSER
	return Types.ref_cursor
   as 
	mycursor Types.ref_cursor;
   begin
	open mycursor for
		select * from Sample;
	return mycursor;
   end;
/

