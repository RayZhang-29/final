create function SAVEUSER(
	name in VARCHAR2,
	age in NUMBER)
   return NUMBER
   is
   begin
	insert into Sample values(name, age);
	return 10;
   end;
/

